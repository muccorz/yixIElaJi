#pragma once

//#include  <vector>

#include "ofMain.h"

class ofApp : public ofBaseApp {
   public:
    // 4key位置（pt）
    constexpr static float KEY_POS[] = {-300, -100, 100, 300};

    ofTrueTypeFont font;
    ofSoundPlayer nei;
    ofImage circle,start;
    ofVideoPlayer background;

    // 歌曲开始播放
    bool gameStarted = false;

    // 游戏模式，默认4key
    int gameModeKey = 4;
    
    // 当前歌曲总node数
    int nodeNum;

    // 所有nodes
    vector<vector<int>> nodes;

    // 歌曲播放进度对应的node进度
    int nodePtr[4] = {0, 0, 0, 0};
    
    // 键按下；键击中
    bool keyRawPressed[4], keyHit[4];

    // 键位置
    int keyPos[4];
    
    int sp = 15;                  // 下落速度
    int offset = 1950 / sp;
    int x = 0;                 // 播放进度
    int level[4] = {1, 2, 3, 4};  // 难易度 后期扩充
    
    int countdown = 0;  //开始后的倒计时

    float fftSmooth[8192];
    int bands;
    
    int decideline = 800 / sp;  // 800
    int track;
    int combo = 0;
    
    string hitMsg = "";
    int hitMsgLastFrame = 0;

    void setup();
    void update();
    void draw();

    void readNodeData(const string &filename, vector<vector<int>> &res, int &tot);

    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y);
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);
};
