#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
    readNodeData("pu.txt", nodes, nodeNum);
    fill_n(nodePtr, gameModeKey, 0);
    
    font.load("PingFang.ttc", 28);
    nei.load("nei.mp3");
    background.load("background.mp4");
    circle.load("circle.png");
    start.load("start.png");
    //    ofSetBackgroundColor(123, 123, 123);
    ofSetBackgroundColor(255,255,255);

    keyPos[0] = ofGetWidth()/2-400;
    keyPos[1] = ofGetWidth()/2-200;
    keyPos[2] = ofGetWidth()/2;
    keyPos[3] = ofGetWidth()/2+200;

    fill(fftSmooth, end(fftSmooth), 0);

    bands = 64;
    //    nei.setVolume(0.2);
    
}

//--------------------------------------------------------------
void ofApp::update() {
    
    ofSoundUpdate();
    if (!gameStarted) {
        ofResetElapsedTimeCounter();
    } else {
        x++;
        background.update();
    }
    
    
    //音频可视化
    float * value = ofSoundGetSpectrum(bands);
    for (int i = 0; i < bands; i++) {
        fftSmooth[i] *= 0.9f;
        if (fftSmooth[i]< value[i]) {
            fftSmooth[i] = value[i];
        }
    }
    
}

//--------------------------------------------------------------
void ofApp::draw() {
    ofSetColor(255, 255, 255,100);
    background.draw(0, 0);
    ofSetColor(0, 0, 0);
    if (!gameStarted && nei.isLoaded() && background.isLoaded()) font.drawString("loaded", 100, 100);
    if (gameStarted) {
      
        ofSetBackgroundColor(255,255,255);
      
        ofSetColor(0,0,0);
//        font.drawString("offset=" + to_string(offset), 100, 100);
        
        //        if (ofGetElapsedTimef() <= 3) {
        //            font.drawString(to_string(3 - (int)ofGetElapsedTimef()), 640, 200);
        //        }
        //        if(ofGetElapsedTimef()>=3){
        
        font.drawString("combo  " + to_string(combo), ofGetWidth()-400, 200);
        
        // 判定
        for (int k=0; k<gameModeKey; ++k) {
            // 处理已经miss掉的node
            while (nodes[k][nodePtr[k]] * 0.06 - x - offset + decideline < -13) {
                ++nodePtr[k];
                hitMsg = "miss";
                hitMsgLastFrame = 30;
                combo = 0;
            }

            if (!keyHit[k]) continue;  // 该键未按下, 跳过

            float dis = abs(nodes[k][nodePtr[k]] * 0.06 - x - offset + decideline);
            if (dis <= 13) {  // 击中node, 进入判定
                if (dis <= 2.5) {
                    hitMsg = "perfect";
                    combo ++;
                } else if (dis <= 5) {
                    hitMsg = "great";
                    combo ++;
                } else if (dis <= 8) {
                    hitMsg = "good";
                    combo ++;
                } else if (dis <= 10) {
                    hitMsg = "safe";
                    combo ++;
                } else {
                    hitMsg = "bad";
                    combo = 0;
                }
                hitMsgLastFrame = 30;
                keyHit[k] = false;  // 本次按键被处理过了
                ++nodePtr[k];  // 这个node被击中了
            }
        }
        
        if (hitMsgLastFrame) {
            font.drawString(hitMsg, ofGetWidth()/2, 300);
            --hitMsgLastFrame;
        }

        // 画落下的node
        for (int k=0; k<gameModeKey; ++k) {
            for (int i = nodePtr[k]; i < nodes[k].size() ; i += 1) {
                float keydown = (x + offset - nodes[k][i] * 0.06) * sp;
//                cout << "d 落下 " << keydown0 <<"时间" << ofGetElapsedTimef()<< endl;
                if (keydown < 0) break;
                // ofDrawCircle(ofGetWidth()/2+KEY_POS[0], keydown0, 10);
                circle.draw(ofGetWidth()/2+KEY_POS[k], keydown);
            }
        }

        // 按键视觉反馈
        ofPushMatrix();
        ofSetLineWidth(5);
        for (int k=0; k<gameModeKey; ++k) {
            if (keyRawPressed[k]) {
                for (int i = 0; i<20; i++) {
                    ofSetColor(0, 0, 0, 255-i*15);
                    ofDrawLine(keyPos[k], decideline*sp - i*10, keyPos[k]+200, decideline*sp - i*10);
                }
            }
        }
        ofPopMatrix();
        
        // 音频可视化
        ofSetColor(0, 0, 0);
        for (int i = 0; i < bands; i++) {
            
            float x;
            if(nei.getPositionMS()>24000){
                x = ofMap(i+10, 20 , bands, 0.18, 0.75)*ofGetWidth();
            }else{
                x = ofMap(i+10, 20 , bands, ofNoise(fftSmooth[i],20)*0.5, 0.75)*ofGetWidth();
            }
            
            int y = decideline * sp;
            int w = ofGetWidth()*0.2/bands;
            int h = -fftSmooth[i]*100 ;
            
            
            //        ofDrawRectangle(x, y, w, h);
            //        ofNoFill();
            
            ofDrawEllipse(x, y, w, h);
            ofDrawEllipse(ofGetWidth()-x, y, w, h);
            
        }
        //                ofPopMatrix();
        ofSetLineWidth(1);

        // 判定线
        ofDrawLine(0, decideline * sp, ofGetWidth(), decideline * sp);

        
    } else{
//        ofDrawRectangle(540, 600, 200, 100);
        start.draw(ofGetWidth()/2-350,600);
        
    }
    
}


void ofApp::readNodeData(const string &filename, vector<vector<int>> &res, int &tot) {
    istringstream in(ofBufferFromFile(filename).getText());
    res.assign(gameModeKey, vector<int>());
    int n, t;
    tot = 0;
    while (in) {
        in >> n >> t;
        res[t].push_back(n);
        ++tot;
    }
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
    
    switch (key) {
            
        case 'd':
            track = ofGetWidth()/2-400;
            keyRawPressed[0] = keyHit[0] = true;
            break;
        case 'f':
            track = ofGetWidth()/2-200;
            keyRawPressed[1] = keyHit[1] = true;
            break;
        case 'j':
            track = ofGetWidth()/2;
            keyRawPressed[2] = keyHit[2] = true;
            break;
        case 'k':
            track = ofGetWidth()/2+200;
            keyRawPressed[3] = keyHit[3] = true;
            break;
//        case 'q':
//            offset += 1;
//            break;
//        case 'w':
//            offset -= 1;
//            break;
    }
    
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

    switch (key) {
        case 'd':
            keyRawPressed[0] = keyHit[0] = false;
            break;
        case 'f':
            keyRawPressed[1] = keyHit[1] = false;
            break;
        case 'j':
            keyRawPressed[2] = keyHit[2] = false;
            break;
        case 'k':
            keyRawPressed[3] = keyHit[3] = false;
            break;
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
    if (!gameStarted && x > ofGetWidth()/2-350 && x < ofGetWidth()/2+350 && y < 726 && y > 600 && nei.isLoaded() && background.isLoaded()) {
        gameStarted = true;
        
        nei.play();
        
        background.play();
        
    }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {}
